<!-- begin footer -->

<div style="clear:both;"></div>
<div id="footer">
	<p>&copy; 2006-<?php echo date('Y') ?> <?php bloginfo('name'); ?>. Test theme wireframe &copy; <a href="http://www.webtoolkit.info">www.webtoolkit.info</a>.</p>
</div>

<?php do_action('wp_footer'); ?>

</body>
</html>